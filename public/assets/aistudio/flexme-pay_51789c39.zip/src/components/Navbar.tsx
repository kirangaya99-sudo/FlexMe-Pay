import React, { useState, useRef, useEffect } from 'react';
import { ShieldCheck, Moon, Sun, ArrowUpRight, LogOut, ChevronDown, CheckCircle2, User, KeyRound, Lock, Shield } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { OWNER_ADMIN_EMAIL } from '../types/auth';
import { FlexMeLogo } from './FlexMeLogo';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isDark: boolean;
  toggleDark: () => void;
  onOpenQuickPay: () => void;
  pendingCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isDark,
  toggleDark,
  onOpenQuickPay,
  pendingCount = 0,
}) => {
  const { currentUser, isLoggedIn, isAdmin, openLoginModal, logout } = useAuth();
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState<boolean>(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsProfileDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4 sm:gap-8">
        
        {/* Zone 1: FlexMe Brand Logo & Wordmark */}
        <div 
          onClick={() => setActiveTab('recharge')}
          className="cursor-pointer transition-transform active:scale-98"
          title="FlexMe Pay Home"
        >
          <FlexMeLogo size="md" />
        </div>

        {/* Zone 2: 4-5 Concise Navigation Links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-600 dark:text-slate-300">
          <button
            onClick={() => setActiveTab('recharge')}
            className={`whitespace-nowrap transition-colors hover:text-slate-950 dark:hover:text-white relative py-1 ${
              activeTab === 'recharge' 
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-indigo-600 dark:after:bg-indigo-400' 
                : ''
            }`}
          >
            Google Play Cards
          </button>
          <button
            onClick={() => setActiveTab('games')}
            className={`whitespace-nowrap transition-colors hover:text-slate-950 dark:hover:text-white relative py-1 ${
              activeTab === 'games' 
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-indigo-600 dark:after:bg-indigo-400' 
                : ''
            }`}
          >
            Game & PW Top-Up
          </button>
          <button
            onClick={() => setActiveTab('targetsmp')}
            className={`whitespace-nowrap transition-colors hover:text-slate-950 dark:hover:text-white relative py-1 flex items-center gap-1.5 ${
              activeTab === 'targetsmp' 
                ? 'text-emerald-600 dark:text-emerald-400 font-bold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-emerald-600 dark:after:bg-emerald-400' 
                : ''
            }`}
          >
            <span>⛏️ TargetSMP Pass</span>
            <span className="text-[10px] font-black px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
              ₹120
            </span>
          </button>
          <button
            onClick={() => setActiveTab('collect')}
            className={`whitespace-nowrap transition-colors hover:text-slate-950 dark:hover:text-white relative py-1 ${
              activeTab === 'collect' 
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-indigo-600 dark:after:bg-indigo-400' 
                : ''
            }`}
          >
            Collect Payment
          </button>
          <button
            onClick={() => setActiveTab('track')}
            className={`whitespace-nowrap transition-colors hover:text-slate-950 dark:hover:text-white relative py-1 flex items-center gap-1.5 ${
              activeTab === 'track' 
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-indigo-600 dark:after:bg-indigo-400' 
                : ''
            }`}
          >
            <span>{isAdmin ? 'Payment Requests' : 'Track & Processing'}</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-black bg-amber-500 text-slate-950 animate-pulse">
                {pendingCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('merchant')}
            className={`whitespace-nowrap transition-colors hover:text-slate-950 dark:hover:text-white relative py-1 flex items-center gap-1.5 ${
              activeTab === 'merchant' 
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-indigo-600 dark:after:bg-indigo-400' 
                : ''
            }`}
          >
            <span>Merchant Desk</span>
            {isAdmin && (
              <span className="w-2 h-2 rounded-full bg-amber-500" title="Admin Active"></span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('support')}
            className={`whitespace-nowrap transition-colors hover:text-slate-950 dark:hover:text-white relative py-1 flex items-center gap-1.5 ${
              activeTab === 'support' 
                ? 'text-indigo-600 dark:text-indigo-400 font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-indigo-600 dark:after:bg-indigo-400' 
                : ''
            }`}
          >
            <span>Helpline Bot</span>
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          </button>
        </nav>

        {/* Zone 3: Instagram Support + Google Login + Theme Toggle + Fast Pay */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          
          {/* Instagram Support @flexme.pay Button */}
          <a
            href="https://instagram.com/flexme.pay"
            target="_blank"
            rel="noopener noreferrer"
            title="Instagram Support: @flexme.pay"
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg text-white bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 shadow-xs transition-all active:scale-95 cursor-pointer"
          >
            <svg className="w-3.5 h-3.5 fill-current shrink-0" viewBox="0 0 24 24">
              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
            </svg>
            <span className="hidden sm:inline font-bold">@flexme.pay</span>
          </a>

          {/* Theme Toggle */}
          <button
            onClick={toggleDark}
            aria-label="Toggle Color Theme"
            className="p-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* User Auth Button / Profile Menu (Email and password strictly never displayed) */}
          {!currentUser ? (
            <button
              onClick={() => openLoginModal()}
              className="flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700/80 rounded-xl border border-slate-300 dark:border-slate-700 shadow-xs transition-all whitespace-nowrap active:scale-98 cursor-pointer"
            >
              <Lock className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Sign In / Login</span>
            </button>
          ) : (
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setIsProfileDropdownOpen(prev => !prev)}
                className="flex items-center gap-2 p-1 sm:px-2.5 sm:py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700/80 transition-colors cursor-pointer"
              >
                {/* User avatar */}
                <div className="relative">
                  {currentUser.avatar ? (
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-7 h-7 rounded-full object-cover border border-indigo-400"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-xs">
                      {currentUser.name.charAt(0)}
                    </div>
                  )}
                  {isAdmin ? (
                    <span className="absolute -top-1 -right-1 w-3 h-3 bg-amber-500 rounded-full border-2 border-white dark:border-slate-900" title="Admin"></span>
                  ) : (
                    <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border border-white dark:border-slate-900"></span>
                  )}
                </div>

                <div className="hidden sm:flex flex-col text-left">
                  <span className="text-xs font-semibold text-slate-900 dark:text-white leading-tight max-w-[110px] truncate">
                    {currentUser.name}
                  </span>
                  <span className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">
                    {isAdmin ? '👑 FlexMe Admin' : 'Verified Member'}
                  </span>
                </div>

                <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
              </button>

              {/* Profile Dropdown Menu */}
              {isProfileDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 py-2 z-50 animate-fade-in">
                  
                  {/* Account Header - Email & password strictly omitted per user requirements */}
                  <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800">
                    <div className="flex items-center gap-1.5 mb-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                        Authenticated Account
                      </span>
                      {isAdmin && (
                        <span className="ml-auto text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200">
                          FlexMe Admin
                        </span>
                      )}
                    </div>
                    <div className="font-semibold text-sm text-slate-900 dark:text-white truncate">
                      {currentUser.name}
                    </div>
                    <div className="text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-0.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                      <span>Credentials Private (Not Displayed)</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setActiveTab('track');
                        setIsProfileDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck className="w-4 h-4 text-indigo-500" />
                      <span>My Orders & Digital Vouchers</span>
                    </button>

                    {isAdmin && (
                      <button
                        onClick={() => {
                          setActiveTab('merchant');
                          setIsProfileDropdownOpen(false);
                        }}
                        className="w-full px-4 py-2 text-left text-xs text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30 flex items-center gap-2 font-medium cursor-pointer"
                      >
                        <KeyRound className="w-4 h-4 text-amber-500" />
                        <span>Merchant Approvals Desk</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        openLoginModal('FORMAT_PASSWORD');
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-amber-700 dark:text-amber-300 hover:bg-amber-50 dark:hover:bg-amber-950/30 flex items-center gap-2 font-medium cursor-pointer"
                    >
                      <KeyRound className="w-4 h-4 text-amber-500" />
                      <span>Format Password (Secret Key)</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        openLoginModal('FORMAT_SECRET_KEY');
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-indigo-700 dark:text-indigo-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/30 flex items-center gap-2 font-medium cursor-pointer"
                    >
                      <Shield className="w-4 h-4 text-indigo-500" />
                      <span>Format Secret Key (Password)</span>
                    </button>

                    <button
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        openLoginModal();
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 cursor-pointer"
                    >
                      <User className="w-4 h-4 text-blue-500" />
                      <span>Switch Account / Sign In</span>
                    </button>

                    <div className="my-1 border-t border-slate-100 dark:border-slate-800"></div>

                    <button
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        logout();
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2 font-medium cursor-pointer"
                    >
                      <LogOut className="w-4 h-4 text-rose-500" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Quick Pay CTA */}
          <button
            onClick={onOpenQuickPay}
            className="flex items-center gap-2 px-3 sm:px-4 py-2 sm:py-2.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 dark:bg-emerald-600 dark:hover:bg-emerald-500 rounded-lg shadow-sm transition-all whitespace-nowrap active:scale-98"
          >
            <span className="hidden sm:inline">Pay via Cashfree</span>
            <span className="sm:hidden">Pay</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Mobile subnav bar for instant tab switching */}
      <div className="lg:hidden flex items-center overflow-x-auto px-4 py-2 border-t border-slate-100 dark:border-slate-800/60 scrollbar-none gap-2 bg-slate-50/50 dark:bg-slate-950/50">
        {[
          { id: 'recharge', label: 'Play Cards' },
          { id: 'targetsmp', label: '⛏️ TargetSMP' },
          { id: 'games', label: 'Top-Ups' },
          { id: 'collect', label: 'Collect Payment' },
          { id: 'track', label: isAdmin ? `Requests (${pendingCount})` : 'Track & Processing' },
          { id: 'support', label: '🤖 Helpline Bot' },
          { id: 'merchant', label: 'Merchant' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
              activeTab === item.id
                ? 'bg-slate-900 text-white dark:bg-emerald-600'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>
    </header>
  );
};

