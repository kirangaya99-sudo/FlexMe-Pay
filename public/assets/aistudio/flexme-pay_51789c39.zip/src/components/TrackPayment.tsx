import React, { useState, useEffect } from 'react';
import { TransactionRecord } from '../types/payment';
import { 
  Search, CheckCircle2, AlertCircle, Clock, Copy, Check, ExternalLink, 
  Printer, UserCheck, Shield, KeyRound, Sparkles, RefreshCw, Send, 
  CheckCheck, ArrowRight, Eye, Phone, Mail, Hash, User, Filter, AlertTriangle,
  Gift, Lock, ChevronRight, Zap, Server, GraduationCap
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { updateTransaction, loadTransactions } from '../utils/storage';
import { playCashfreeSoundbox, generatePlayStoreRedeemCode } from '../utils/soundbox';
import { sendVoucherCodeToCustomer } from '../services/emailService';
import confetti from 'canvas-confetti';

export const isTargetSmpOrder = (tx: TransactionRecord): boolean => {
  return tx.purpose.toLowerCase().includes('targetsmp') || tx.purpose.toLowerCase().includes('target smp');
};

export const isPwOrder = (tx: TransactionRecord): boolean => {
  return tx.purpose.toLowerCase().includes('pw ') || 
         tx.purpose.toLowerCase().includes('class 9') || 
         tx.purpose.toLowerCase().includes('physics wallah');
};

interface TrackPaymentProps {
  transactions: TransactionRecord[];
  onSelectTransaction: (tx: TransactionRecord) => void;
}

export const TrackPayment: React.FC<TrackPaymentProps> = ({ transactions: initialTransactions, onSelectTransaction }) => {
  const { currentUser, isAdmin, isLoggedIn, openLoginModal } = useAuth();
  
  // Real-time local transactions state to support instant live refresh without full page reload
  const [liveTransactions, setLiveTransactions] = useState<TransactionRecord[]>(initialTransactions);
  const [query, setQuery] = useState<string>('');
  const [hasSearched, setHasSearched] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Owner approval modal state
  const [approvingTx, setApprovingTx] = useState<TransactionRecord | null>(null);
  const [adminCustomCode, setAdminCustomCode] = useState<string>('');
  const [isSubmittingApproval, setIsSubmittingApproval] = useState<boolean>(false);
  const [approvalFeedback, setApprovalFeedback] = useState<string | null>(null);

  // Owner filter: 'ALL' | 'PENDING' | 'SUCCESS'
  const [ownerFilter, setOwnerFilter] = useState<'ALL' | 'PENDING' | 'SUCCESS'>('ALL');

  // Keep liveTransactions synchronized with props
  useEffect(() => {
    setLiveTransactions(initialTransactions);
  }, [initialTransactions]);

  // Sync with global cross-component event
  useEffect(() => {
    const handleUpdate = () => {
      setLiveTransactions(loadTransactions());
    };
    window.addEventListener('app_transactions_updated', handleUpdate);
    return () => window.removeEventListener('app_transactions_updated', handleUpdate);
  }, []);

  const handleManualRefresh = () => {
    setIsRefreshing(true);
    const updated = loadTransactions();
    setLiveTransactions(updated);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  // Open owner confirmation modal for a specific transaction
  const handleOpenApprovalModal = (tx: TransactionRecord) => {
    setApprovingTx(tx);
    if (!isTargetSmpOrder(tx) && !isPwOrder(tx)) {
      setAdminCustomCode(generatePlayStoreRedeemCode());
    } else {
      setAdminCustomCode('');
    }
    setApprovalFeedback(null);
  };

  // Confirm payment request by Owner
  const handleConfirmAndApprove = (e: React.FormEvent) => {
    e.preventDefault();
    if (!approvingTx) return;

    setIsSubmittingApproval(true);
    const approvedAt = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    let finalCode: string | undefined;
    let feedbackMsg = '';

    if (isTargetSmpOrder(approvingTx)) {
      // User explicit instruction: "Target SMP में कोड मत दो, बस पेमेंट कर दो। पेमेंट का फॉर्म हो गया, उसका सक्सेस हो गया। बस उसमें कोड Play Store का नहीं दो।"
      finalCode = 'TARGETSMP_ACTIVE';
      feedbackMsg = `TargetSMP Pass verified for ${approvingTx.customerName}! Minecraft player is now Whitelisted. (No Play Store code issued).`;
    } else if (isPwOrder(approvingTx)) {
      // User explicit instruction: "PW में तुम कोड नहीं डालना।"
      finalCode = 'PW_CLASS9_ACTIVE';
      feedbackMsg = `Physics Wallah Class 9th batch confirmed for student ${approvingTx.customerName}! (No Play Store code issued).`;
    } else {
      // User explicit instruction: "Target SMP और FF Max, BGMI आदि में Play Store का कोड डालना ठीक है"
      finalCode = adminCustomCode.trim() || generatePlayStoreRedeemCode();
      feedbackMsg = `Order #${approvingTx.orderId} verified successfully! Google Play code ${finalCode} is now active.`;
    }

    // 1. Update in persistent storage
    const updated = updateTransaction(approvingTx.orderId, {
      status: 'SUCCESS',
      redeemCode: finalCode,
      adminApprovedAt: approvedAt,
    });
    setLiveTransactions(updated);

    // 2. Play Soundbox confirmation chime
    playCashfreeSoundbox(approvingTx.amount, 'en');

    // 3. Dispatch celebratory confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore in environments without canvas
    }

    // 4. Log customer dispatch email/Instagram notification
    try {
      sendVoucherCodeToCustomer({
        orderId: approvingTx.orderId,
        customerName: approvingTx.customerName,
        customerEmail: approvingTx.customerEmail,
        amount: approvingTx.amount,
        redeemCode: finalCode,
        adminApprovedAt: approvedAt,
      });
    } catch (err) {
      console.warn('Customer notification logged:', err);
    }

    setApprovalFeedback(feedbackMsg);
    setIsSubmittingApproval(false);

    // Close modal after brief pause
    setTimeout(() => {
      setApprovingTx(null);
      setApprovalFeedback(null);
    }, 1800);
  };

  // Search filter
  const searchResults = liveTransactions.filter((tx) => {
    if (!query.trim()) return false;
    const q = query.trim().toLowerCase();
    return (
      tx.orderId.toLowerCase().includes(q) ||
      tx.cfPaymentId.toLowerCase().includes(q) ||
      tx.customerPhone.includes(q) ||
      tx.customerEmail.toLowerCase().includes(q) ||
      tx.customerName.toLowerCase().includes(q) ||
      (tx.utrNumber && tx.utrNumber.toLowerCase().includes(q)) ||
      (tx.redeemCode && tx.redeemCode.toLowerCase().includes(q))
    );
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
  };

  // Owner calculations
  const pendingRequests = liveTransactions.filter(t => t.status === 'PENDING');
  const approvedRequests = liveTransactions.filter(t => t.status === 'SUCCESS');
  const totalVolume = liveTransactions.reduce((sum, t) => sum + (t.status === 'SUCCESS' ? t.amount : 0), 0);
  const pendingVolume = pendingRequests.reduce((sum, t) => sum + t.amount, 0);

  const ownerDisplayedRequests = liveTransactions.filter(tx => {
    if (ownerFilter === 'PENDING') return tx.status === 'PENDING';
    if (ownerFilter === 'SUCCESS') return tx.status === 'SUCCESS';
    return true;
  });

  // Customer recent processing orders (orders that are pending or were recently completed)
  const customerRecentOrders = liveTransactions.slice(0, 4);

  return (
    <section id="track-section" className="py-10 bg-slate-50/70 dark:bg-slate-950 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* ========================================================= */}
        {/* VIEW 1: OWNER / ADMIN LIVE REQUESTS & CONFIRMATION DESK   */}
        {/* ========================================================= */}
        {isAdmin ? (
          <div className="space-y-8 animate-fade-in">
            {/* Owner Header */}
            <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border border-indigo-900/60 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
              
              <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2.5 py-1 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                      FlexMe Admin Master Desk
                    </span>
                    <span className="text-xs text-slate-400">· Direct Live Queue</span>
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                    Live Incoming Payment Requests & Confirmation
                  </h2>
                  <p className="mt-1 text-sm text-slate-300 max-w-2xl leading-relaxed">
                    All customer payment requests are listed below automatically without searching. Review customer name, email, UTR, and click <strong className="text-emerald-400">"Confirm Payment"</strong> to instantly approve. (TargetSMP and PW are activated directly without Play Store codes; Games receive 16-char Play Store codes).
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    onClick={handleManualRefresh}
                    disabled={isRefreshing}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold backdrop-blur-xs transition-all cursor-pointer border border-white/10"
                    title="Refresh live queue"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                    <span>{isRefreshing ? 'Refreshing...' : 'Live Refresh'}</span>
                  </button>
                  <a
                    href="https://instagram.com/flexme.pay"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 text-white text-xs font-bold hover:opacity-95 shadow-md transition-all"
                  >
                    <span>Instagram @flexme.pay</span>
                  </a>
                </div>
              </div>

              {/* 3 KPI Summary Metrics */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-6 border-t border-white/10">
                <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20">
                  <div className="flex items-center justify-between text-xs font-medium text-amber-300">
                    <span>Pending Requests (Action Needed)</span>
                    <Clock className="w-4 h-4 text-amber-400 animate-pulse" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-amber-200 mt-1">
                    {pendingRequests.length} Requests
                  </div>
                  <div className="text-[11px] text-amber-300/80 mt-1">
                    ₹{pendingVolume.toLocaleString('en-IN')} pending verification
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
                  <div className="flex items-center justify-between text-xs font-medium text-emerald-300">
                    <span>Approved & Dispatched</span>
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-emerald-200 mt-1">
                    {approvedRequests.length} Orders
                  </div>
                  <div className="text-[11px] text-emerald-300/80 mt-1">
                    ₹{totalVolume.toLocaleString('en-IN')} successfully settled
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20">
                  <div className="flex items-center justify-between text-xs font-medium text-indigo-300">
                    <span>Total Payment Requests</span>
                    <Shield className="w-4 h-4 text-indigo-400" />
                  </div>
                  <div className="text-2xl sm:text-3xl font-black text-indigo-200 mt-1">
                    {liveTransactions.length} Total
                  </div>
                  <div className="text-[11px] text-indigo-300/80 mt-1">
                    FlexMe Admin Protected
                  </div>
                </div>
              </div>
            </div>

            {/* Filter Tabs for Owner */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2 p-1.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
                <button
                  onClick={() => setOwnerFilter('ALL')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    ownerFilter === 'ALL'
                      ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  All Requests ({liveTransactions.length})
                </button>
                <button
                  onClick={() => setOwnerFilter('PENDING')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    ownerFilter === 'PENDING'
                      ? 'bg-amber-500 text-slate-950 shadow-xs'
                      : 'text-amber-700 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/40'
                  }`}
                >
                  <span>Pending Approval</span>
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-amber-900 text-amber-100 font-bold">
                    {pendingRequests.length}
                  </span>
                </button>
                <button
                  onClick={() => setOwnerFilter('SUCCESS')}
                  className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                    ownerFilter === 'SUCCESS'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-emerald-700 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40'
                  }`}
                >
                  Approved ({approvedRequests.length})
                </button>
              </div>

              {/* Optional Quick search for Owner */}
              <div className="relative max-w-xs w-full">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Filter by UTR, Name or Phone..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl text-xs border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            {/* List of Incoming Requests */}
            <div className="space-y-3">
              {ownerDisplayedRequests
                .filter(tx => {
                  if (!query.trim()) return true;
                  const q = query.trim().toLowerCase();
                  return (
                    tx.orderId.toLowerCase().includes(q) ||
                    tx.customerName.toLowerCase().includes(q) ||
                    tx.customerPhone.includes(q) ||
                    tx.customerEmail.toLowerCase().includes(q) ||
                    (tx.utrNumber && tx.utrNumber.toLowerCase().includes(q))
                  );
                })
                .map((tx) => {
                  const isSmp = isTargetSmpOrder(tx);
                  const isPw = isPwOrder(tx);

                  return (
                    <div
                      key={tx.orderId}
                      className={`p-5 rounded-2xl border transition-all ${
                        tx.status === 'PENDING'
                          ? 'bg-amber-50/60 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800 ring-2 ring-amber-500/20 shadow-md'
                          : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm'
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        
                        {/* Left: Customer & Payment Details */}
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center gap-3 flex-wrap">
                            <span className={`px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5 ${
                              tx.status === 'PENDING'
                                ? 'bg-amber-100 text-amber-900 dark:bg-amber-900/60 dark:text-amber-200 border border-amber-300 dark:border-amber-700'
                                : 'bg-emerald-100 text-emerald-900 dark:bg-emerald-900/60 dark:text-emerald-200 border border-emerald-300 dark:border-emerald-700'
                            }`}>
                              {tx.status === 'PENDING' ? (
                                <>
                                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-ping"></span>
                                  Pending Owner Confirmation
                                </>
                              ) : (
                                <>
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                                  {isSmp ? 'TargetSMP Whitelisted ⛏️' : isPw ? 'PW Class 9th Enrolled 🎓' : 'Confirmed & Code Sent'}
                                </>
                              )}
                            </span>

                            {isSmp && (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                                TargetSMP Pass (No Play Store Code)
                              </span>
                            )}

                            {isPw && (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-300 dark:border-indigo-800">
                                PW Class 9th (No Play Store Code)
                              </span>
                            )}

                            <span className="text-xs font-mono font-bold text-slate-500 dark:text-slate-400">
                              #{tx.orderId}
                            </span>

                            <span className="text-xs text-slate-400">
                              {tx.createdAt}
                            </span>
                          </div>

                          {/* Customer Row */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs pt-1">
                            <div className="flex items-center gap-1.5">
                              <User className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                              <strong className="text-slate-900 dark:text-white truncate">{tx.customerName}</strong>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Phone className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                              <span className="text-slate-700 dark:text-slate-300 font-mono">{tx.customerPhone}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <Mail className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                              <span className="text-slate-700 dark:text-slate-300 truncate">{tx.customerEmail}</span>
                            </div>
                          </div>

                          {/* UTR & Purpose */}
                          <div className="flex items-center gap-4 text-xs text-slate-600 dark:text-slate-400 pt-1 flex-wrap">
                            <div>
                              <span className="font-semibold text-slate-700 dark:text-slate-300">Bank UTR / Ref: </span>
                              <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-200 dark:border-indigo-800">
                                {tx.utrNumber || tx.cfPaymentId}
                              </span>
                            </div>
                            <div>
                              <span className="font-semibold text-slate-700 dark:text-slate-300">Purpose: </span>
                              <span className="font-medium text-slate-800 dark:text-slate-200">{tx.purpose}</span>
                            </div>
                          </div>

                          {/* If already approved: show status details */}
                          {tx.status === 'SUCCESS' && (
                            isSmp ? (
                              <div className="mt-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between text-xs">
                                <div className="flex items-center gap-2">
                                  <Server className="w-4 h-4 text-emerald-600 shrink-0" />
                                  <span className="text-slate-600 dark:text-slate-300 font-medium">TargetSMP Membership:</span>
                                  <span className="font-bold text-emerald-700 dark:text-emerald-300">WHITELISTED & ACTIVE 🟢 (play.targetsmp.in)</span>
                                </div>
                                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">Direct Server Pass</span>
                              </div>
                            ) : isPw ? (
                              <div className="mt-2 p-2.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/60 flex items-center justify-between text-xs">
                                <div className="flex items-center gap-2">
                                  <GraduationCap className="w-4 h-4 text-indigo-600 shrink-0" />
                                  <span className="text-slate-600 dark:text-slate-300 font-medium">PW Batch Status:</span>
                                  <span className="font-bold text-indigo-700 dark:text-indigo-300">CLASS 9TH ENROLLED 🎓</span>
                                </div>
                                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-semibold">Direct Mobile Admission</span>
                              </div>
                            ) : tx.redeemCode && !tx.redeemCode.startsWith('TARGETSMP') && !tx.redeemCode.startsWith('PW') ? (
                              <div className="mt-2 p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between text-xs">
                                <div className="flex items-center gap-2">
                                  <Gift className="w-4 h-4 text-emerald-600 shrink-0" />
                                  <span className="text-slate-600 dark:text-slate-300">Google Play Code:</span>
                                  <span className="font-mono font-black text-sm text-slate-900 dark:text-white select-all">
                                    {tx.redeemCode}
                                  </span>
                                </div>
                                <button
                                  onClick={() => handleCopy(tx.redeemCode!)}
                                  className="p-1.5 text-emerald-600 hover:text-emerald-700 dark:text-emerald-400 cursor-pointer"
                                  title="Copy Code"
                                >
                                  {copiedCode === tx.redeemCode ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                                </button>
                              </div>
                            ) : null
                          )}
                        </div>

                        {/* Right: Amount & Direct Confirmation Button */}
                        <div className="flex sm:flex-row lg:flex-col items-end justify-between gap-3 shrink-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-slate-200 dark:border-slate-800">
                          <div className="text-left lg:text-right">
                            <span className="text-[11px] text-slate-500 uppercase font-bold block">Payment Amount</span>
                            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 tabular-nums">
                              ₹{tx.amount.toLocaleString('en-IN')}
                            </span>
                          </div>

                          {tx.status === 'PENDING' ? (
                            <button
                              onClick={() => handleOpenApprovalModal(tx)}
                              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-98 text-white font-bold text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer whitespace-nowrap"
                            >
                              <Zap className="w-4 h-4 fill-current" />
                              <span>
                                {isSmp ? 'Confirm & Whitelist Player' : isPw ? 'Confirm PW Class 9th Admission' : 'Confirm & Generate Code'}
                              </span>
                            </button>
                          ) : (
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => onSelectTransaction(tx)}
                                className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 text-xs font-semibold cursor-pointer"
                              >
                                Receipt ↗
                              </button>
                              <a
                                href="https://instagram.com/flexme.pay"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 text-white text-xs font-bold hover:opacity-95"
                              >
                                Instagram DM
                              </a>
                            </div>
                          )}
                        </div>

                      </div>
                    </div>
                  );
                })}

              {ownerDisplayedRequests.length === 0 && (
                <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Queue is Clear!
                  </h3>
                  <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                    There are no payment requests matching the selected filter. Any new customer payments will appear here instantly.
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* ========================================================= */
          /* VIEW 2: CUSTOMER PAYMENT PROCESSING & ORDER TRACKING VIEW */
          /* ========================================================= */
          <div className="space-y-8 animate-fade-in">
            {/* Customer Header */}
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/50 border border-indigo-200 dark:border-indigo-800 text-xs font-bold text-indigo-700 dark:text-indigo-300 mb-3">
                <Clock className="w-3.5 h-3.5 text-indigo-600" />
                <span>Live Payment Processing & Verification</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white">
                Track Payment Status & Retrieve Access
              </h2>
              <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Check whether your payment is <strong className="text-amber-600 dark:text-amber-400">Processing / Pending</strong> or <strong className="text-emerald-600 dark:text-emerald-400">Verified & Approved</strong> by FlexMe Admin. TargetSMP access is whitelisted directly, PW batches are enrolled on your number, and games receive Play Store redeem codes.
              </p>
            </div>

            {/* Customer Active / Recent Orders Section */}
            {customerRecentOrders.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                      Recent Payment Transactions
                    </h3>
                  </div>

                  <button
                    onClick={handleManualRefresh}
                    disabled={isRefreshing}
                    className="flex items-center gap-1.5 text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
                    <span>{isRefreshing ? 'Checking Live Status...' : 'Check Live Status'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {customerRecentOrders.map((tx) => {
                    const isSmp = isTargetSmpOrder(tx);
                    const isPw = isPwOrder(tx);

                    return (
                      <div
                        key={tx.orderId}
                        className={`p-5 rounded-2xl border transition-all ${
                          tx.status === 'PENDING'
                            ? 'bg-amber-50/50 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800 shadow-sm'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-sm'
                        }`}
                      >
                        {/* Status Header */}
                        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                          <div className="flex items-center gap-2">
                            <span className={`w-2.5 h-2.5 rounded-full ${
                              tx.status === 'SUCCESS' ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'
                            }`}></span>
                            <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                              {tx.orderId}
                            </span>
                          </div>

                          <span className={`text-xs font-black px-2.5 py-0.5 rounded-md ${
                            tx.status === 'SUCCESS'
                              ? 'text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/60'
                              : 'text-amber-800 dark:text-amber-300 bg-amber-100 dark:bg-amber-950/80 animate-pulse'
                          }`}>
                            {tx.status === 'SUCCESS' ? 'PAID & APPROVED' : 'PAYMENT PROCESSING ⏳'}
                          </span>
                        </div>

                        {/* Transaction Details */}
                        <div className="py-3 text-xs space-y-1.5 text-slate-600 dark:text-slate-300">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Amount:</span>
                            <strong className="text-emerald-600 dark:text-emerald-400 text-sm">₹{tx.amount.toLocaleString('en-IN')}</strong>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Purpose:</span>
                            <span className="font-medium text-slate-800 dark:text-slate-200 truncate max-w-[200px]">{tx.purpose}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Submitted UTR:</span>
                            <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{tx.utrNumber || tx.cfPaymentId}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Date & Time:</span>
                            <span>{tx.createdAt}</span>
                          </div>
                        </div>

                        {/* Pending State Banner */}
                        {tx.status === 'PENDING' && (
                          <div className="p-3.5 rounded-xl bg-amber-100/70 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 space-y-2">
                            <div className="flex items-center gap-2 font-bold">
                              <Clock className="w-4 h-4 text-amber-600 animate-spin shrink-0" />
                              <span>Payment Pending Admin Verification</span>
                            </div>
                            <p className="text-[11px] leading-relaxed text-amber-800/90 dark:text-amber-300/90">
                              {isSmp 
                                ? 'FLEX Admin is reviewing your TargetSMP payment ref. Once approved, your Minecraft player is whitelisted on play.targetsmp.in directly without needing a Play Store code.'
                                : isPw
                                ? 'FLEX Admin is verifying your PW Class 9th course fee. Once approved, your admission will be activated on your registered mobile number directly.'
                                : `FLEX Admin is reviewing your payment ref (UTR: ${tx.utrNumber || tx.cfPaymentId}). As soon as confirmed, your 16-character code will unlock right here.`}
                            </p>
                            <div className="pt-1 flex items-center justify-between text-[11px]">
                              <button
                                onClick={handleManualRefresh}
                                className="font-bold text-indigo-700 dark:text-indigo-300 hover:underline flex items-center gap-1 cursor-pointer"
                              >
                                <RefreshCw className="w-3 h-3" />
                                <span>Refresh Status</span>
                              </button>
                              <a
                                href="https://instagram.com/flexme.pay"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="font-bold text-pink-600 dark:text-pink-400 hover:underline"
                              >
                                Message @flexme.pay ↗
                              </a>
                            </div>
                          </div>
                        )}

                        {/* Success State */}
                        {tx.status === 'SUCCESS' && (
                          isSmp ? (
                            /* TargetSMP Membership Card - No Play Store Code */
                            <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/50 dark:to-teal-950/50 border-2 border-emerald-400 dark:border-emerald-700 space-y-2.5">
                              <div className="flex items-center justify-between text-[11px] font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                                <span className="flex items-center gap-1.5">
                                  <Server className="w-3.5 h-3.5 text-emerald-600" />
                                  TargetSMP Minecraft Membership
                                </span>
                                <span className="text-emerald-600">Whitelisted ✅</span>
                              </div>

                              <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-emerald-300 dark:border-emerald-800 space-y-2">
                                <div className="flex items-center justify-between">
                                  <div>
                                    <span className="text-[10px] text-slate-500 uppercase font-semibold block">Server Address</span>
                                    <span className="font-mono text-sm font-black text-slate-900 dark:text-white select-all">play.targetsmp.in</span>
                                  </div>
                                  <button
                                    onClick={() => handleCopy('play.targetsmp.in')}
                                    className="p-1.5 rounded-md text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950 transition-colors cursor-pointer flex items-center gap-1 text-xs font-bold"
                                    title="Copy Server IP"
                                  >
                                    {copiedCode === 'play.targetsmp.in' ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                                    <span>{copiedCode === 'play.targetsmp.in' ? 'Copied' : 'Copy IP'}</span>
                                  </button>
                                </div>

                                <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100 dark:border-slate-800 text-[11px]">
                                  <div>
                                    <span className="text-slate-500 block">Minecraft Port:</span>
                                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">25565 (Java) / 19132 (PE)</span>
                                  </div>
                                  <div>
                                    <span className="text-slate-500 block">Status:</span>
                                    <span className="font-bold text-emerald-600">Pass Active 🟢</span>
                                  </div>
                                </div>
                              </div>

                              <div className="pt-1 flex items-center justify-between text-xs">
                                <span className="text-[11px] text-emerald-800 dark:text-emerald-300">
                                  Join Minecraft now with your registered IGN. (No code required).
                                </span>
                                <button
                                  onClick={() => onSelectTransaction(tx)}
                                  className="text-slate-500 hover:text-slate-800 dark:hover:text-white underline cursor-pointer"
                                >
                                  Receipt
                                </button>
                              </div>
                            </div>
                          ) : isPw ? (
                            /* PW Class 9th Admission Card - No Play Store Code */
                            <div className="p-4 rounded-xl bg-gradient-to-r from-indigo-50 to-blue-50 dark:from-indigo-950/50 dark:to-blue-950/50 border-2 border-indigo-400 dark:border-indigo-700 space-y-2.5">
                              <div className="flex items-center justify-between text-[11px] font-bold text-indigo-700 dark:text-indigo-400 uppercase tracking-wider">
                                <span className="flex items-center gap-1.5">
                                  <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                                  Physics Wallah Class 9th Batch
                                </span>
                                <span className="text-indigo-600">Enrolled ✅</span>
                              </div>

                              <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-indigo-300 dark:border-indigo-800 space-y-1.5">
                                <div className="text-xs text-slate-700 dark:text-slate-200">
                                  <span className="text-slate-500 block text-[10px] uppercase font-semibold">Enrolled Course</span>
                                  <strong className="text-sm text-indigo-950 dark:text-indigo-200 block">{tx.purpose}</strong>
                                </div>
                                <div className="pt-1 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px]">
                                  <span className="text-slate-500">Student:</span>
                                  <span className="font-bold text-slate-900 dark:text-white">{tx.customerName}</span>
                                </div>
                              </div>

                              <div className="pt-1 flex items-center justify-between text-xs">
                                <span className="text-[11px] text-indigo-800 dark:text-indigo-300">
                                  Admission confirmed. Login on the PW app with your mobile. (No code required).
                                </span>
                                <button
                                  onClick={() => onSelectTransaction(tx)}
                                  className="text-slate-500 hover:text-slate-800 dark:hover:text-white underline cursor-pointer"
                                >
                                  Receipt
                                </button>
                              </div>
                            </div>
                          ) : tx.redeemCode && !tx.redeemCode.startsWith('TARGETSMP') && !tx.redeemCode.startsWith('PW') ? (
                            /* Games & Play Store Voucher Code Card */
                            <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-50 to-indigo-50 dark:from-emerald-950/50 dark:to-indigo-950/50 border-2 border-emerald-400 dark:border-emerald-700 space-y-2">
                              <div className="flex items-center justify-between text-[11px] font-bold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
                                <span>Google Play Store Redeem Code</span>
                                <span className="text-emerald-600">Verified ✅</span>
                              </div>

                              <div className="flex items-center justify-between bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-emerald-300 dark:border-emerald-800">
                                <span className="font-mono text-base font-black text-slate-900 dark:text-white tracking-wider select-all">
                                  {tx.redeemCode}
                                </span>
                                <button
                                  onClick={() => handleCopy(tx.redeemCode!)}
                                  className="p-1.5 rounded-md text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950 transition-colors cursor-pointer"
                                  title="Copy Code"
                                >
                                  {copiedCode === tx.redeemCode ? (
                                    <Check className="w-4 h-4 text-emerald-600" />
                                  ) : (
                                    <Copy className="w-4 h-4" />
                                  )}
                                </button>
                              </div>

                              <div className="pt-1 flex items-center justify-between text-xs">
                                <a
                                  href={`https://play.google.com/redeem?code=${tx.redeemCode}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="font-bold text-emerald-600 hover:underline flex items-center gap-1"
                                >
                                  <span>Redeem on Play Store</span>
                                  <ExternalLink className="w-3.5 h-3.5" />
                                </a>
                                <button
                                  onClick={() => onSelectTransaction(tx)}
                                  className="text-slate-500 hover:text-slate-800 dark:hover:text-white underline cursor-pointer"
                                >
                                  Receipt
                                </button>
                              </div>
                            </div>
                          ) : null
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Search Bar for Other Orders */}
            <div className="max-w-2xl bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
              <div className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Lookup Another Order by ID, Mobile Number or UTR:
              </div>

              <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={query}
                    onChange={(e) => {
                      setQuery(e.target.value);
                      setHasSearched(false);
                    }}
                    placeholder="Enter Order ID (CF_PW_...), Mobile Number, or UTR..."
                    className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
                <button
                  type="submit"
                  className="py-3 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-sm transition-all whitespace-nowrap active:scale-98 cursor-pointer"
                >
                  Search Order
                </button>
              </form>

              {/* Owner Quick Sign In reminder */}
              {!isLoggedIn && (
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
                  <span>Are you the Store Owner?</span>
                  <button
                    onClick={() => openLoginModal()}
                    className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer"
                  >
                    Login as FLEX Admin to Review All Orders ↗
                  </button>
                </div>
              )}
            </div>

            {/* Searched Results */}
            {hasSearched && (
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  Search Results ({searchResults.length})
                </h3>

                {searchResults.length === 0 ? (
                  <div className="p-8 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                    <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                      No order found matching "{query}"
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Check your 12-digit UTR reference number or registered mobile number.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {searchResults.map((tx) => {
                      const isSmp = isTargetSmpOrder(tx);
                      const isPw = isPwOrder(tx);

                      return (
                        <div
                          key={tx.orderId}
                          className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-sm space-y-4"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                              #{tx.orderId}
                            </span>
                            <span className={`text-xs font-black px-2 py-0.5 rounded ${
                              tx.status === 'SUCCESS'
                                ? 'text-emerald-700 bg-emerald-100 dark:bg-emerald-950/60'
                                : 'text-amber-800 bg-amber-100 dark:bg-amber-950/80 animate-pulse'
                            }`}>
                              {tx.status === 'SUCCESS' ? 'PAID & APPROVED' : 'PROCESSING ⏳'}
                            </span>
                          </div>

                          <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                            <div><strong>Amount:</strong> ₹{tx.amount}</div>
                            <div><strong>Customer:</strong> {tx.customerName} ({tx.customerPhone})</div>
                            <div><strong>Purpose:</strong> {tx.purpose}</div>
                            <div><strong>Bank UTR:</strong> <span className="font-mono">{tx.utrNumber || tx.cfPaymentId}</span></div>
                            <div><strong>Date:</strong> {tx.createdAt}</div>
                          </div>

                          {tx.status === 'SUCCESS' && (
                            isSmp ? (
                              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs">
                                <span className="text-[10px] font-bold text-emerald-600 block uppercase">TargetSMP Server IP</span>
                                <span className="font-mono text-sm font-black text-slate-900 dark:text-white">play.targetsmp.in (Whitelisted)</span>
                              </div>
                            ) : isPw ? (
                              <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-xs">
                                <span className="text-[10px] font-bold text-indigo-600 block uppercase">PW Class 9th Status</span>
                                <span className="text-sm font-black text-indigo-900 dark:text-white">Admission Enrolled & Active</span>
                              </div>
                            ) : tx.redeemCode && !tx.redeemCode.startsWith('TARGETSMP') && !tx.redeemCode.startsWith('PW') ? (
                              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
                                <div>
                                  <span className="text-[10px] font-bold text-emerald-600 block uppercase">Redeem Code</span>
                                  <span className="font-mono text-sm font-black text-slate-900 dark:text-white">{tx.redeemCode}</span>
                                </div>
                                <button
                                  onClick={() => handleCopy(tx.redeemCode!)}
                                  className="p-2 text-emerald-600 cursor-pointer"
                                >
                                  {copiedCode === tx.redeemCode ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                                </button>
                              </div>
                            ) : null
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ========================================================= */}
        {/* OWNER DIRECT CONFIRMATION MODAL                           */}
        {/* ========================================================= */}
        {approvingTx && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
            <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-7 space-y-5">
              
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-2.5">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-md">
                    {isTargetSmpOrder(approvingTx) ? (
                      <Server className="w-5 h-5" />
                    ) : isPwOrder(approvingTx) ? (
                      <GraduationCap className="w-5 h-5" />
                    ) : (
                      <KeyRound className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-white">
                      {isTargetSmpOrder(approvingTx)
                        ? 'Confirm TargetSMP Pass & Whitelist'
                        : isPwOrder(approvingTx)
                        ? 'Confirm PW Class 9th Admission'
                        : 'Confirm Customer Payment & Issue Code'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      FlexMe Admin Action · Order #{approvingTx.orderId}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setApprovingTx(null)}
                  className="text-slate-400 hover:text-slate-700 dark:hover:text-white text-lg p-1.5 cursor-pointer"
                >
                  ✕
                </button>
              </div>

              {/* Customer & Payment Snapshot */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Customer Name:</span>
                  <strong className="text-slate-900 dark:text-white">{approvingTx.customerName}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Mobile Phone:</span>
                  <span className="font-mono text-slate-800 dark:text-slate-200">{approvingTx.customerPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Customer Email:</span>
                  <span className="text-slate-800 dark:text-slate-200">{approvingTx.customerEmail}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Purpose / Plan:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[240px]">{approvingTx.purpose}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Payment Amount:</span>
                  <strong className="text-emerald-600 dark:text-emerald-400 text-sm">₹{approvingTx.amount.toLocaleString('en-IN')}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Customer Submitted UTR:</span>
                  <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded">
                    {approvingTx.utrNumber || approvingTx.cfPaymentId}
                  </span>
                </div>
              </div>

              {/* Modal Body Based on Order Type */}
              <form onSubmit={handleConfirmAndApprove} className="space-y-4">
                
                {isTargetSmpOrder(approvingTx) ? (
                  /* TargetSMP: No Play Store Code Form */
                  <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-xs space-y-2.5">
                    <div className="flex items-center gap-2 font-bold text-emerald-800 dark:text-emerald-200">
                      <Server className="w-4 h-4 text-emerald-600" />
                      <span>TargetSMP Whitelist Activation (No Code Needed)</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      Target SMP में Play Store का कोड नहीं देना है। बस पेमेंट कन्फर्म करके प्लेयर को TargetSMP सर्वर पर Whitelisted एक्टिवेट करें।
                    </p>
                    <div className="p-2.5 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-emerald-200 dark:border-emerald-800 text-[11px] space-y-1">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Target Server:</span>
                        <span className="font-mono font-bold text-emerald-700 dark:text-emerald-300">play.targetsmp.in</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Action:</span>
                        <span className="font-bold text-emerald-600">Direct Pass Whitelist</span>
                      </div>
                    </div>
                  </div>
                ) : isPwOrder(approvingTx) ? (
                  /* PW: No Play Store Code Form */
                  <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-300 dark:border-indigo-800 text-xs space-y-2.5">
                    <div className="flex items-center gap-2 font-bold text-indigo-800 dark:text-indigo-200">
                      <GraduationCap className="w-4 h-4 text-indigo-600" />
                      <span>Physics Wallah Class 9th Admission (No Code Needed)</span>
                    </div>
                    <p className="text-[11px] text-slate-600 dark:text-slate-300 leading-relaxed">
                      PW में Play Store का कोड नहीं देना है। स्टूडेंट की क्लास 9th फीस कन्फर्म करें और एडमिशन सीधे उसके रजिस्टर्ड मोबाइल पर एक्टिवेट करें।
                    </p>
                    <div className="p-2.5 bg-white/80 dark:bg-slate-900/80 rounded-xl border border-indigo-200 dark:border-indigo-800 text-[11px] space-y-1">
                      <div className="flex justify-between">
                        <span className="text-slate-500">Student:</span>
                        <span className="font-bold text-slate-900 dark:text-white">{approvingTx.customerName}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-500">Batch Type:</span>
                        <span className="font-bold text-indigo-600">Class 9th Batch</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Games (Free Fire, BGMI) & PlayStore: 16-Char Play Store Code Input */
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-800 dark:text-slate-200">
                        Google Play 16-Character Redeem Code:
                      </label>
                      <button
                        type="button"
                        onClick={() => setAdminCustomCode(generatePlayStoreRedeemCode())}
                        className="text-[11px] font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3 h-3" />
                        <span>Generate Random</span>
                      </button>
                    </div>

                    <input
                      type="text"
                      required
                      value={adminCustomCode}
                      onChange={(e) => setAdminCustomCode(e.target.value.toUpperCase())}
                      placeholder="GPLY-XXXX-XXXX-XXXX"
                      className="w-full font-mono text-base font-black px-4 py-3 rounded-xl border border-indigo-300 dark:border-indigo-700 bg-indigo-50/50 dark:bg-indigo-950/40 text-slate-900 dark:text-white tracking-widest text-center focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    <span className="text-[11px] text-slate-500 mt-1 block">
                      This code will unlock in customer's Track Order screen immediately.
                    </span>
                  </div>
                )}

                {approvalFeedback && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-300 dark:border-emerald-800 text-xs text-emerald-800 dark:text-emerald-300 font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{approvalFeedback}</span>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setApprovingTx(null)}
                    className="py-3 px-4 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-300 hover:bg-slate-50 cursor-pointer"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmittingApproval || (!isTargetSmpOrder(approvingTx) && !isPwOrder(approvingTx) && !adminCustomCode.trim())}
                    className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                  >
                    <Check className="w-4 h-4" />
                    <span>
                      {isSubmittingApproval
                        ? 'Confirming...'
                        : isTargetSmpOrder(approvingTx)
                        ? 'Confirm & Whitelist'
                        : isPwOrder(approvingTx)
                        ? 'Confirm & Enroll PW'
                        : 'Confirm & Unlock Code'}
                    </span>
                  </button>
                </div>
              </form>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};
