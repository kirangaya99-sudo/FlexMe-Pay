import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { MASTER_SECRET_KEY } from '../utils/userStore';
import {
  X,
  Lock,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  AlertCircle,
  EyeOff,
  User,
  RefreshCw,
  Shield,
  Check,
} from 'lucide-react';
import { FlexMeLogo } from './FlexMeLogo';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'LOGIN' | 'FORMAT_PASSWORD' | 'FORMAT_SECRET_KEY';
}

type Step = 'EMAIL' | 'PASSWORD' | 'FORMAT_PASSWORD' | 'FORMAT_SECRET_KEY';

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'LOGIN',
}) => {
  const {
    loginWithEmailPassword,
    registerNewAccount,
    formatAccountPassword,
    formatAccountSecretKey,
    checkEmailRegistered,
    currentUser,
  } = useAuth();

  const [step, setStep] = useState<Step>('EMAIL');
  const [emailInput, setEmailInput] = useState<string>('');
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [nameInput, setNameInput] = useState<string>('');
  const [secretKeyInput, setSecretKeyInput] = useState<string>('');

  // Format password fields (Reset password using Secret Key)
  const [formatEmail, setFormatEmail] = useState<string>('');
  const [formatSecretKey, setFormatSecretKey] = useState<string>('');
  const [formatNewPassword, setFormatNewPassword] = useState<string>('');
  const [formatConfirmPassword, setFormatConfirmPassword] = useState<string>('');

  // Format secret key fields (Reset secret key using Password)
  const [secKeyEmail, setSecKeyEmail] = useState<string>('');
  const [secKeyCurrentPassword, setSecKeyCurrentPassword] = useState<string>('');
  const [secKeyNewSecretKey, setSecKeyNewSecretKey] = useState<string>('');
  const [secKeyConfirmSecretKey, setSecKeyConfirmSecretKey] = useState<string>('');

  const [isExistingUser, setIsExistingUser] = useState<boolean>(true);
  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successMsg, setSuccessMsg] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Reset fields when opening modal - NEVER prefill passwords or private credentials
  useEffect(() => {
    if (isOpen) {
      if (initialMode === 'FORMAT_SECRET_KEY') {
        setStep('FORMAT_SECRET_KEY');
      } else if (initialMode === 'FORMAT_PASSWORD') {
        setStep('FORMAT_PASSWORD');
      } else {
        setStep('EMAIL');
      }
      setEmailInput('');
      setPasswordInput(''); // ALWAYS blank, typed manually
      setNameInput('');
      setSecretKeyInput('');
      setFormatSecretKey('');
      setFormatNewPassword('');
      setFormatConfirmPassword('');
      setSecKeyCurrentPassword('');
      setSecKeyNewSecretKey('');
      setSecKeyConfirmSecretKey('');
      setErrorMsg('');
      setSuccessMsg('');

      if (currentUser?.email) {
        setFormatEmail(currentUser.email);
        setSecKeyEmail(currentUser.email);
      } else {
        setFormatEmail('');
        setSecKeyEmail('');
      }
    }
  }, [isOpen, initialMode, currentUser]);

  if (!isOpen) return null;

  // Step 1: User enters email
  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const trimmed = emailInput.trim().toLowerCase();
    if (!trimmed || !trimmed.includes('@')) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }

    const exists = checkEmailRegistered(trimmed);
    setIsExistingUser(exists);
    setFormatEmail(trimmed);
    setSecKeyEmail(trimmed);
    // Explicitly guarantee password field is completely blank
    setPasswordInput('');
    setStep('PASSWORD');
  };

  // Step 2: User manually enters password
  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (!passwordInput.trim()) {
      setErrorMsg('Please enter your password.');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      if (isExistingUser) {
        // Authenticate existing user with their password
        const res = loginWithEmailPassword(emailInput.trim(), passwordInput.trim());
        setIsLoading(false);
        if (!res.success) {
          setErrorMsg(res.message || 'Incorrect password.');
        } else {
          onClose();
        }
      } else {
        // New user: Save account and password
        const nameToUse = nameInput.trim() || 'Verified User';
        const res = registerNewAccount({
          email: emailInput.trim(),
          password: passwordInput.trim(),
          name: nameToUse,
          secretKey: secretKeyInput.trim() || MASTER_SECRET_KEY,
        });
        setIsLoading(false);
        if (!res.success) {
          setErrorMsg(res.message || 'Failed to save account.');
        } else {
          onClose();
        }
      }
    }, 300);
  };

  // Step 3A: Format Password using Secret Key
  const handleFormatPasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const targetEmail = formatEmail.trim().toLowerCase();
    if (!targetEmail || !targetEmail.includes('@')) {
      setErrorMsg('Please enter the email address of the account to format.');
      return;
    }

    if (!formatSecretKey.trim()) {
      setErrorMsg('Secret Key is required to format your password.');
      return;
    }

    if (!formatNewPassword || formatNewPassword.length < 4) {
      setErrorMsg('New password must be at least 4 characters long.');
      return;
    }

    if (formatNewPassword !== formatConfirmPassword) {
      setErrorMsg('New password and confirm password do not match.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const res = formatAccountPassword({
        email: targetEmail,
        secretKey: formatSecretKey.trim(),
        newPassword: formatNewPassword.trim(),
      });

      setIsLoading(false);
      if (!res.success) {
        setErrorMsg(res.message);
      } else {
        setSuccessMsg('Password has been formatted and saved successfully! Please log in with your new password.');
        setEmailInput(targetEmail);
        setPasswordInput(''); // Cleared so user types their new formatted password manually
        setIsExistingUser(true);
        setTimeout(() => {
          setStep('PASSWORD');
          setSuccessMsg('Password formatted! Type your new password to sign in.');
        }, 1200);
      }
    }, 350);
  };

  // Step 3B: Format / Custom Secret Key using Password
  const handleFormatSecretKeySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const targetEmail = secKeyEmail.trim().toLowerCase();
    if (!targetEmail || !targetEmail.includes('@')) {
      setErrorMsg('Please enter your account email.');
      return;
    }

    if (!secKeyCurrentPassword.trim()) {
      setErrorMsg('Account password is required to format/reset your Secret Key.');
      return;
    }

    if (!secKeyNewSecretKey || secKeyNewSecretKey.trim().length < 3) {
      setErrorMsg('New custom Secret Key must be at least 3 characters long.');
      return;
    }

    if (secKeyNewSecretKey.trim() !== secKeyConfirmSecretKey.trim()) {
      setErrorMsg('New Secret Key and confirmation do not match.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      const res = formatAccountSecretKey({
        email: targetEmail,
        password: secKeyCurrentPassword.trim(),
        newSecretKey: secKeyNewSecretKey.trim(),
      });

      setIsLoading(false);
      if (!res.success) {
        setErrorMsg(res.message);
      } else {
        setSuccessMsg('Your custom Secret Key has been successfully formatted and saved!');
        setSecKeyCurrentPassword('');
        setSecKeyNewSecretKey('');
        setSecKeyConfirmSecretKey('');
        setTimeout(() => {
          setStep('PASSWORD');
          setEmailInput(targetEmail);
          setPasswordInput('');
        }, 1500);
      }
    }, 350);
  };

  return (
    <div
      onClick={(e) => {
        if (e.target === e.currentTarget && !isLoading) onClose();
      }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in overflow-y-auto"
    >
      <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-6">
        {/* Header Bar */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <FlexMeLogo size="sm" showSubtitle={false} />
            <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono font-bold">
              ZERO-LEAK PRIVACY
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Security & Strict Privacy Notice Header */}
        <div className="bg-indigo-50/70 dark:bg-indigo-950/40 px-6 py-2.5 border-b border-indigo-100 dark:border-indigo-900/60 flex items-center gap-2 text-xs text-indigo-900 dark:text-indigo-200">
          <EyeOff className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
          <span className="text-[11px] leading-tight">
            <strong>Privacy Guard:</strong> Email and password are never displayed in the app. Only you remember your credentials.
          </span>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-7 space-y-5">
          {/* STEP 1: ENTER EMAIL */}
          {step === 'EMAIL' && (
            <div className="space-y-5">
              <div className="text-center space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-2 shadow-xs">
                  <User className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Enter Your Account Email
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Enter your email address to proceed. You will be prompted to enter your password on the next step.
                </p>
              </div>

              <form onSubmit={handleEmailSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    Account Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    autoFocus
                    value={emailInput}
                    onChange={(e) => setEmailInput(e.target.value)}
                    placeholder="Enter your email to continue..."
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-xs"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Your email is kept confidential and strictly never displayed in the app after logging in.
                  </p>
                </div>

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 font-medium flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-3.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
                >
                  <span>Continue to Password</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* Format Password Direct Access */}
              <div className="text-center pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1.5">
                <button
                  type="button"
                  onClick={() => {
                    setFormatEmail(emailInput || '');
                    setStep('FORMAT_PASSWORD');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold cursor-pointer block w-full"
                >
                  Forgot your password? Format password with Secret Key
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSecKeyEmail(emailInput || '');
                    setStep('FORMAT_SECRET_KEY');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-[11px] text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-300 underline cursor-pointer block w-full"
                >
                  Forgot/Reset Secret Key? Format Secret Key with Password
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: ENTER PASSWORD (MANUALLY TYPED, NEVER PREFILLED) */}
          {step === 'PASSWORD' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setStep('EMAIL');
                    setPasswordInput('');
                    setErrorMsg('');
                  }}
                  className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Change Email</span>
                </button>
                <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Email Accepted</span>
                </span>
              </div>

              <div className="text-center space-y-1">
                <div className="w-12 h-12 rounded-2xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto mb-2 shadow-xs">
                  <Lock className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  {isExistingUser ? 'Enter Account Password' : 'Set & Save Password'}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {isExistingUser
                    ? 'Please type your password below to sign in.'
                    : 'New account detected. Type a password to save for this account.'}
                </p>
              </div>

              <form onSubmit={handlePasswordSubmit} className="space-y-4">
                {!isExistingUser && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Your Full Name / Nickname *
                    </label>
                    <input
                      type="text"
                      required
                      value={nameInput}
                      onChange={(e) => setNameInput(e.target.value)}
                      placeholder="e.g. Vikas Sharma"
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Password *
                    </label>
                    {isExistingUser && (
                      <button
                        type="button"
                        onClick={() => {
                          setFormatEmail(emailInput);
                          setStep('FORMAT_PASSWORD');
                          setErrorMsg('');
                          setSuccessMsg('');
                        }}
                        className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline cursor-pointer"
                      >
                        Forgot password? Format it
                      </button>
                    )}
                  </div>
                  {/* Password field: completely empty on open, typed manually, masked with bullets */}
                  <input
                    type="password"
                    required
                    autoFocus
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="Type your password..."
                    autoComplete="current-password"
                    className="w-full px-4 py-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-base tracking-widest focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono shadow-xs"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Password is typed by you manually and is strictly never shown in the app.
                  </p>
                </div>

                {!isExistingUser && (
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Custom Secret Key for Password Formatting
                    </label>
                    <input
                      type="password"
                      value={secretKeyInput}
                      onChange={(e) => setSecretKeyInput(e.target.value)}
                      placeholder="Create a custom secret key (e.g. MY-KEY-999)..."
                      className="w-full px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">
                      You can format your password with this key, or format this key anytime with your password.
                    </p>
                  </div>
                )}

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 font-medium flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {successMsg && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-700 dark:text-emerald-300 font-medium flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{successMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  <Lock className="w-4 h-4" />
                  <span>
                    {isLoading
                      ? 'Verifying...'
                      : isExistingUser
                      ? 'Sign In with Password'
                      : 'Save Password & Create Account'}
                  </span>
                </button>
              </form>

              {/* Recovery Options Bar */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setFormatEmail(emailInput);
                    setStep('FORMAT_PASSWORD');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-amber-600 dark:text-amber-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Format Password</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSecKeyEmail(emailInput);
                    setStep('FORMAT_SECRET_KEY');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-indigo-600 dark:text-indigo-400 hover:underline font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5" />
                  <span>Format Secret Key</span>
                </button>
              </div>
            </div>
          )}

          {/* STEP 3A: FORMAT PASSWORD USING SECRET KEY */}
          {step === 'FORMAT_PASSWORD' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setStep('EMAIL');
                    setPasswordInput('');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sign In</span>
                </button>
                <span className="text-[11px] font-bold text-amber-700 dark:text-amber-300 bg-amber-100 dark:bg-amber-950 px-2 py-0.5 rounded-full">
                  Secret Key Required
                </span>
              </div>

              {/* 2-Way Symmetrical Toggle */}
              <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => {
                    setStep('FORMAT_PASSWORD');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="flex-1 py-1.5 px-2 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <KeyRound className="w-3.5 h-3.5 text-amber-500" />
                  <span>Format Password</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStep('FORMAT_SECRET_KEY');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="flex-1 py-1.5 px-2 rounded-lg text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Format Secret Key</span>
                </button>
              </div>

              <div className="text-center space-y-1">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Format Forgotten Password
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Enter your Secret Key to format your password and establish a new one.
                </p>
              </div>

              <form onSubmit={handleFormatPasswordSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Account Email to Format *
                  </label>
                  <input
                    type="email"
                    required
                    value={formatEmail}
                    onChange={(e) => setFormatEmail(e.target.value)}
                    placeholder="Enter account email..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Enter Secret Key *
                  </label>
                  {/* Secret Key input: typed manually, masked with type="password" */}
                  <input
                    type="password"
                    required
                    autoFocus
                    value={formatSecretKey}
                    onChange={(e) => setFormatSecretKey(e.target.value)}
                    placeholder="Enter your Secret Key..."
                    className="w-full px-3.5 py-2.5 rounded-xl border-2 border-amber-300 dark:border-amber-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-sm tracking-wider focus:outline-none focus:ring-2 focus:ring-amber-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Enter the secret key configured for your account.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      New Formatted Password *
                    </label>
                    <input
                      type="password"
                      required
                      value={formatNewPassword}
                      onChange={(e) => setFormatNewPassword(e.target.value)}
                      placeholder="New password..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Confirm New Password *
                    </label>
                    <input
                      type="password"
                      required
                      value={formatConfirmPassword}
                      onChange={(e) => setFormatConfirmPassword(e.target.value)}
                      placeholder="Confirm password..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 font-medium flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {successMsg && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-700 dark:text-emerald-300 font-medium flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{successMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>{isLoading ? 'Formatting Password...' : 'Format & Save New Password'}</span>
                </button>
              </form>
            </div>
          )}

          {/* STEP 3B: FORMAT SECRET KEY USING PASSWORD (USER CAN SET CUSTOM SECRET KEY) */}
          {step === 'FORMAT_SECRET_KEY' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => {
                    setStep('EMAIL');
                    setPasswordInput('');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Sign In</span>
                </button>
                <span className="text-[11px] font-bold text-indigo-700 dark:text-indigo-300 bg-indigo-100 dark:bg-indigo-950 px-2 py-0.5 rounded-full">
                  Password Required
                </span>
              </div>

              {/* 2-Way Symmetrical Toggle */}
              <div className="flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => {
                    setStep('FORMAT_PASSWORD');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="flex-1 py-1.5 px-2 rounded-lg text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <KeyRound className="w-3.5 h-3.5 text-amber-500" />
                  <span>Format Password</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setStep('FORMAT_SECRET_KEY');
                    setErrorMsg('');
                    setSuccessMsg('');
                  }}
                  className="flex-1 py-1.5 px-2 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Shield className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Format Secret Key</span>
                </button>
              </div>

              <div className="text-center space-y-1">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Format / Set Custom Secret Key
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Verify your account password to format and assign your custom Secret Key.
                </p>
              </div>

              <form onSubmit={handleFormatSecretKeySubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Account Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={secKeyEmail}
                    onChange={(e) => setSecKeyEmail(e.target.value)}
                    placeholder="Enter your account email..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Current Account Password *
                  </label>
                  <input
                    type="password"
                    required
                    autoFocus
                    value={secKeyCurrentPassword}
                    onChange={(e) => setSecKeyCurrentPassword(e.target.value)}
                    placeholder="Type current password to verify..."
                    className="w-full px-3.5 py-2.5 rounded-xl border-2 border-indigo-300 dark:border-indigo-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono text-sm tracking-wider focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    Your password confirms your ownership before formatting the Secret Key.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      New Custom Secret Key *
                    </label>
                    <input
                      type="password"
                      required
                      value={secKeyNewSecretKey}
                      onChange={(e) => setSecKeyNewSecretKey(e.target.value)}
                      placeholder="e.g. MY-CUSTOM-KEY-77"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Confirm Custom Secret Key *
                    </label>
                    <input
                      type="password"
                      required
                      value={secKeyConfirmSecretKey}
                      onChange={(e) => setSecKeyConfirmSecretKey(e.target.value)}
                      placeholder="Confirm custom key..."
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-mono focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 font-medium flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {successMsg && (
                  <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-700 dark:text-emerald-300 font-medium flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>{successMsg}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  <Shield className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
                  <span>{isLoading ? 'Formatting Secret Key...' : 'Format & Save Custom Secret Key'}</span>
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
