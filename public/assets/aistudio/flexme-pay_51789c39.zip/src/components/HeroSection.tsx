import React from 'react';
import { ArrowRight, Zap, Shield, CheckCircle2, Lock, Smartphone } from 'lucide-react';

interface HeroSectionProps {
  onStartRecharge: () => void;
  onStartCollect: () => void;
  onOpenMerchant: () => void;
  onStartTargetSmp?: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onStartRecharge,
  onStartCollect,
  onOpenMerchant,
  onStartTargetSmp,
}) => {
  return (
    <section className="relative overflow-hidden pt-8 pb-14 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-b from-slate-50/70 via-white to-slate-50/30 dark:from-slate-900 dark:via-slate-900/70 dark:to-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main 2-Column Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          
          {/* Left Column: Proposition and Actions */}
          <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
            
            {/* Unboxed Metadata Trust Line */}
            <div className="flex items-center gap-2 text-xs font-medium text-slate-500 dark:text-slate-400 flex-wrap">
              <span className="text-pink-600 dark:text-pink-400 font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-pink-500 animate-pulse"></span>
                FLEXME PAY OFFICIAL
              </span>
              <span aria-hidden="true">·</span>
              <span className="text-indigo-600 dark:text-indigo-400 font-semibold">FlexMe Admin Protected</span>
              <span aria-hidden="true">·</span>
              <a href="https://instagram.com/flexme.pay" target="_blank" rel="noopener noreferrer" className="text-pink-600 dark:text-pink-400 font-bold hover:underline">
                Instagram: @flexme.pay
              </a>
            </div>

            {/* Headline with balanced wrap */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 dark:text-white leading-[1.15]" style={{ textWrap: 'balance' }}>
              FlexMe Pay: Play Store Recharge & TargetSMP Server Passes.
            </h1>

            {/* Subheading / Value Proposition */}
            <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
              Buy 100% genuine Google Play redeem codes, renew your <strong className="text-emerald-600 dark:text-emerald-400 font-bold">TargetSMP</strong> Minecraft server pass, and collect UPI payments instantly with <strong className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 font-extrabold">FlexMe Pay</strong>. Verified by <strong className="text-slate-800 dark:text-slate-200">FlexMe Admin</strong> with 24/7 Instagram support (<a href="https://instagram.com/flexme.pay" target="_blank" rel="noopener noreferrer" className="text-pink-600 dark:text-pink-400 font-semibold hover:underline">@flexme.pay</a>).
            </p>

            {/* CTA Button Group */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onStartRecharge}
                className="flex items-center gap-2.5 px-6 py-3.5 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:scale-98 rounded-xl shadow-md shadow-indigo-600/20 transition-all whitespace-nowrap"
              >
                <span>Buy Play Store Code</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onStartCollect}
                className="flex items-center gap-2 px-5 py-3.5 text-sm font-semibold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700/80 border border-slate-200 dark:border-slate-700 rounded-xl transition-all whitespace-nowrap"
              >
                <Zap className="w-4 h-4 text-emerald-500" />
                <span>Collect Custom Payment</span>
              </button>

              {onStartTargetSmp && (
                <button
                  onClick={onStartTargetSmp}
                  className="flex items-center gap-2 px-5 py-3.5 text-sm font-semibold text-emerald-800 dark:text-emerald-200 bg-emerald-50 dark:bg-emerald-950/60 hover:bg-emerald-100 border border-emerald-300 dark:border-emerald-800 rounded-xl transition-all whitespace-nowrap cursor-pointer"
                >
                  <span>⛏️ TargetSMP Pass (₹120/mo)</span>
                </button>
              )}

              <button
                onClick={onOpenMerchant}
                className="text-xs font-medium text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white underline underline-offset-4 decoration-slate-300 hover:decoration-slate-900 transition-colors py-2 px-1 whitespace-nowrap"
              >
                Merchant Dashboard & API
              </button>
            </div>

            {/* Trust Evidence Adjacency */}
            <div className="pt-4 grid grid-cols-2 sm:grid-cols-3 gap-4 border-t border-slate-200/80 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                <span>Instant 5s Code SMS</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
                <span>Cashfree 256-Bit SSL</span>
              </div>
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                <span>All UPI Apps Supported</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Focal Carrier */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-800 shadow-xl bg-slate-900 aspect-[16/10] sm:aspect-[16/11]">
              <img
                src="/src/assets/images/playstore_payment_hero_1793430819286.jpg"
                alt="Cashfree payment collection terminal and Google Play Store voucher"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center transform hover:scale-102 transition-transform duration-500"
              />
              
              {/* Overlay trust scrim */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent flex flex-col justify-end p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs uppercase tracking-wider font-semibold text-emerald-400">Verified Integration</p>
                    <p className="text-sm font-bold text-white">Cashfree Payments Gateway v2.4</p>
                  </div>
                  <div className="bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 px-2.5 py-1 rounded text-[11px] font-mono">
                    ONLINE · 99.98% UP
                  </div>
                </div>
              </div>
            </div>

            {/* Quick floating voucher preview card */}
            <div className="absolute -bottom-4 -left-3 sm:-bottom-5 sm:-left-5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 shadow-lg flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 flex items-center justify-center text-emerald-600 dark:text-emerald-400">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">Instant UPI Soundbox</p>
                <p className="text-xs font-bold text-slate-900 dark:text-white">Live Voice Confirmation</p>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
