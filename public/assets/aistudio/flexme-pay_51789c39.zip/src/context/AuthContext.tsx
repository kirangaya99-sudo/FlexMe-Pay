import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { UserProfile, AuthContextType } from '../types/auth';
import {
  findUserByEmail,
  verifyUserPassword,
  saveNewUser,
  formatUserPassword,
  formatUserSecretKey,
  isOwnerAdminEmail,
  INITIAL_REGISTERED_USERS,
  loadUsers,
} from '../utils/userStore';

const AUTH_STORAGE_KEY = 'playstore_pw_active_session_v3';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    try {
      const stored = localStorage.getItem(AUTH_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
      return null;
    } catch {
      return null;
    }
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [loginModalInitialMode, setLoginModalInitialMode] = useState<
    'LOGIN' | 'FORMAT_PASSWORD' | 'FORMAT_SECRET_KEY'
  >('LOGIN');

  // Sync active session
  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(AUTH_STORAGE_KEY);
      }
      window.dispatchEvent(new CustomEvent('app_auth_state_changed', { detail: currentUser }));
    } catch (e) {
      console.error('Failed to sync auth session', e);
    }
  }, [currentUser]);

  const openLoginModal = (mode?: 'LOGIN' | 'FORMAT_PASSWORD' | 'FORMAT_SECRET_KEY' | unknown) => {
    if (mode === 'FORMAT_PASSWORD' || mode === 'FORMAT_SECRET_KEY') {
      setLoginModalInitialMode(mode);
    } else {
      setLoginModalInitialMode('LOGIN');
    }
    setIsLoginModalOpen(true);
  };

  const closeLoginModal = () => {
    setIsLoginModalOpen(false);
  };

  const checkEmailRegistered = (email: string): boolean => {
    return !!findUserByEmail(email);
  };

  const loginWithEmailPassword = (
    email: string,
    password: string
  ): { success: boolean; message?: string } => {
    const result = verifyUserPassword(email, password);
    if (!result.success || !result.user) {
      return { success: false, message: result.message || 'Incorrect password.' };
    }

    const profile: UserProfile = {
      id: result.user.id,
      name: result.user.name,
      email: result.user.email,
      role: isOwnerAdminEmail(result.user.email) ? 'admin' : result.user.role,
      avatar: result.user.avatar,
      loginTime: new Date().toISOString(),
    };

    setCurrentUser(profile);
    setIsLoginModalOpen(false);
    return { success: true };
  };

  const registerNewAccount = (data: {
    name: string;
    email: string;
    password: string;
    secretKey?: string;
  }): { success: boolean; message?: string } => {
    const user = saveNewUser(data);
    const profile: UserProfile = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: isOwnerAdminEmail(user.email) ? 'admin' : user.role,
      avatar: user.avatar,
      loginTime: new Date().toISOString(),
    };

    setCurrentUser(profile);
    setIsLoginModalOpen(false);
    return { success: true };
  };

  const formatAccountPassword = (data: {
    email: string;
    secretKey: string;
    newPassword: string;
  }): { success: boolean; message: string } => {
    const result = formatUserPassword(data.email, data.secretKey, data.newPassword);
    if (result.success && result.user) {
      if (currentUser && currentUser.email.toLowerCase() === data.email.toLowerCase()) {
        setCurrentUser({
          ...currentUser,
          name: result.user.name,
        });
      }
    }
    return { success: result.success, message: result.message };
  };

  const formatAccountSecretKey = (data: {
    email: string;
    password: string;
    newSecretKey: string;
  }): { success: boolean; message: string } => {
    const result = formatUserSecretKey(data.email, data.password, data.newSecretKey);
    return { success: result.success, message: result.message };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const isLoggedIn = currentUser !== null;
  const isAdmin =
    currentUser !== null &&
    (isOwnerAdminEmail(currentUser.email) || currentUser.role === 'admin');

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isLoggedIn,
        isAdmin,
        isLoginModalOpen,
        loginModalInitialMode,
        openLoginModal,
        closeLoginModal,
        loginWithEmailPassword,
        registerNewAccount,
        formatAccountPassword,
        formatAccountSecretKey,
        checkEmailRegistered,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    return {
      currentUser: null,
      isLoggedIn: false,
      isAdmin: false,
      isLoginModalOpen: false,
      loginModalInitialMode: 'LOGIN',
      openLoginModal: () => {},
      closeLoginModal: () => {},
      loginWithEmailPassword: () => ({ success: false, message: 'Auth not initialized' }),
      registerNewAccount: () => ({ success: false, message: 'Auth not initialized' }),
      formatAccountPassword: () => ({ success: false, message: 'Auth not initialized' }),
      formatAccountSecretKey: () => ({ success: false, message: 'Auth not initialized' }),
      checkEmailRegistered: () => false,
      logout: () => {},
    };
  }
  return context;
};
