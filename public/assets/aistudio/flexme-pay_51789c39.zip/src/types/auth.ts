export interface UserProfile {
  id: string;
  name: string;
  // NOTE: Email is stored in session object for internal matching / verification,
  // but strictly NEVER rendered or displayed anywhere on screen per security rules.
  email: string;
  role: 'admin' | 'customer';
  avatar: string;
  loginTime: string;
}

export const OWNER_ADMIN_EMAIL = 'raunakop223@gmail.com';

export interface AuthContextType {
  currentUser: UserProfile | null;
  isLoggedIn: boolean;
  isAdmin: boolean;
  isLoginModalOpen: boolean;
  loginModalInitialMode: 'LOGIN' | 'FORMAT_PASSWORD' | 'FORMAT_SECRET_KEY';
  openLoginModal: (mode?: 'LOGIN' | 'FORMAT_PASSWORD' | 'FORMAT_SECRET_KEY' | unknown) => void;
  closeLoginModal: () => void;
  loginWithEmailPassword: (
    email: string,
    password: string
  ) => { success: boolean; message?: string };
  registerNewAccount: (data: {
    name: string;
    email: string;
    password: string;
    secretKey?: string;
  }) => { success: boolean; message?: string };
  formatAccountPassword: (data: {
    email: string;
    secretKey: string;
    newPassword: string;
  }) => { success: boolean; message: string };
  formatAccountSecretKey: (data: {
    email: string;
    password: string;
    newSecretKey: string;
  }) => { success: boolean; message: string };
  checkEmailRegistered: (email: string) => boolean;
  logout: () => void;
}
