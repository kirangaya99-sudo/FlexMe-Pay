import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { GoogleUser, AuthContextType, OWNER_ADMIN_EMAIL } from '../types/auth';

const AUTH_STORAGE_KEY = 'playstore_pw_user_auth_v1';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const DEFAULT_OWNER_PROFILE: GoogleUser = {
  id: 'usr_google_owner_raunak',
  name: 'Raunak Kumar',
  email: OWNER_ADMIN_EMAIL,
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
  role: 'admin',
  givenName: 'Raunak',
  familyName: 'Kumar',
  verified: true,
  loginTime: new Date().toISOString(),
  provider: 'google',
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<GoogleUser | null>(() => {
    try {
      const stored = localStorage.getItem(AUTH_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
      // Return default owner logged in initially so admin capabilities are ready to use
      return DEFAULT_OWNER_PROFILE;
    } catch {
      return DEFAULT_OWNER_PROFILE;
    }
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);

  // Sync to localStorage
  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(AUTH_STORAGE_KEY);
      }
      window.dispatchEvent(new CustomEvent('app_auth_state_changed', { detail: currentUser }));
    } catch (e) {
      console.error('Failed to sync auth state to localStorage', e);
    }
  }, [currentUser]);

  const openLoginModal = () => setIsLoginModalOpen(true);
  const closeLoginModal = () => setIsLoginModalOpen(false);

  const loginWithGoogle = (customDetails?: { name: string; email: string; avatar?: string }) => {
    const email = customDetails?.email.trim().toLowerCase() || 'customer.google@gmail.com';
    const name = customDetails?.name.trim() || 'Google User';
    const isAdmin = email === OWNER_ADMIN_EMAIL.toLowerCase();

    // Generate consistent avatar seed if none given
    const avatar = customDetails?.avatar || 
      `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}&backgroundColor=4f46e5,06b6d4,10b981`;

    const user: GoogleUser = {
      id: `usr_g_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: name,
      email: email,
      avatar: avatar,
      role: isAdmin ? 'admin' : 'customer',
      givenName: name.split(' ')[0] || name,
      familyName: name.split(' ').slice(1).join(' ') || undefined,
      verified: true,
      loginTime: new Date().toISOString(),
      provider: 'google',
    };

    setCurrentUser(user);
    setIsLoginModalOpen(false);
  };

  const loginAsOwner = () => {
    setCurrentUser(DEFAULT_OWNER_PROFILE);
    setIsLoginModalOpen(false);
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const isLoggedIn = currentUser !== null;
  const isAdmin = currentUser !== null && (currentUser.email.toLowerCase() === OWNER_ADMIN_EMAIL.toLowerCase() || currentUser.role === 'admin');

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isLoggedIn,
        isAdmin,
        isLoginModalOpen,
        openLoginModal,
        closeLoginModal,
        loginWithGoogle,
        loginAsOwner,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
