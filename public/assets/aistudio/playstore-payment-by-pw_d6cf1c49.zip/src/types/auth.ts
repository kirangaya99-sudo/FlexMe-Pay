export interface GoogleUser {
  id: string;
  name: string;
  email: string;
  avatar: string;
  role: 'admin' | 'customer';
  givenName?: string;
  familyName?: string;
  verified: boolean;
  loginTime: string;
  provider: 'google';
}

export const OWNER_ADMIN_EMAIL = 'raunakgaya99@gmail.com';

export interface AuthContextType {
  currentUser: GoogleUser | null;
  isLoggedIn: boolean;
  isAdmin: boolean;
  isLoginModalOpen: boolean;
  openLoginModal: () => void;
  closeLoginModal: () => void;
  loginWithGoogle: (customDetails?: { name: string; email: string; avatar?: string }) => void;
  loginAsOwner: () => void;
  logout: () => void;
}
