import React, { useState } from 'react';
import { TransactionRecord } from '../types/payment';
import { Search, CheckCircle2, AlertCircle, Clock, Copy, Check, ExternalLink, Printer, UserCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface TrackPaymentProps {
  transactions: TransactionRecord[];
  onSelectTransaction: (tx: TransactionRecord) => void;
}

export const TrackPayment: React.FC<TrackPaymentProps> = ({ transactions, onSelectTransaction }) => {
  const { currentUser, isLoggedIn, openLoginModal } = useAuth();
  const [query, setQuery] = useState<string>('');
  const [hasSearched, setHasSearched] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  const filtered = transactions.filter((tx) => {
    if (!query.trim()) return false;
    const q = query.trim().toLowerCase();
    return (
      tx.orderId.toLowerCase().includes(q) ||
      tx.cfPaymentId.toLowerCase().includes(q) ||
      tx.customerPhone.includes(q) ||
      tx.customerEmail.toLowerCase().includes(q) ||
      tx.customerName.toLowerCase().includes(q) ||
      (tx.redeemCode && tx.redeemCode.toLowerCase().includes(q))
    );
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <section id="track-section" className="py-12 bg-white dark:bg-slate-900 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="max-w-3xl mb-10">
          <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2">
            Order Lookup & Verification
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            Track Cashfree Payment & Retrieve Code
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-400">
            Check payment confirmation, view Cashfree bank reference numbers, and retrieve your 16-character Google Play Store redeem code anytime.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-2xl bg-slate-50 dark:bg-slate-800/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 mb-8">
          <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setHasSearched(false);
                }}
                placeholder="Enter Order ID (CF_PW_...), Mobile Number, or Email..."
                className="w-full pl-11 pr-4 py-3 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <button
              type="submit"
              className="py-3 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-sm transition-all whitespace-nowrap active:scale-98 cursor-pointer"
            >
              Track Order
            </button>
          </form>

          {/* Quick sample search helper & Google account sync */}
          <div className="mt-3 text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 flex-wrap">
            {isLoggedIn && currentUser?.email && (
              <button
                type="button"
                onClick={() => {
                  setQuery(currentUser.email);
                  setHasSearched(true);
                }}
                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-indigo-50 dark:bg-indigo-950/40 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 font-medium hover:bg-indigo-100"
              >
                <svg className="w-3 h-3" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
                </svg>
                <span>View my Google orders ({currentUser.email})</span>
              </button>
            )}

            <span>Try searching:</span>
            <button
              type="button"
              onClick={() => {
                setQuery('884920');
                setHasSearched(true);
              }}
              className="font-mono text-indigo-600 dark:text-indigo-400 underline hover:text-indigo-800"
            >
              884920
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => {
                setQuery('98765');
                setHasSearched(true);
              }}
              className="font-mono text-indigo-600 dark:text-indigo-400 underline hover:text-indigo-800"
            >
              98765 (Phone)
            </button>
            <span aria-hidden="true">·</span>
            <button
              type="button"
              onClick={() => {
                setQuery('GPLY');
                setHasSearched(true);
              }}
              className="font-mono text-indigo-600 dark:text-indigo-400 underline hover:text-indigo-800"
            >
              GPLY (Redeem Codes)
            </button>
          </div>
        </div>

        {/* Results Area */}
        {hasSearched && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Search Results ({filtered.length})
            </h3>

            {filtered.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 dark:bg-slate-800/40 rounded-2xl border border-slate-200 dark:border-slate-800">
                <AlertCircle className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                  No transaction found matching "{query}"
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Check if you entered the correct Cashfree Order ID or registered 10-digit mobile number.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filtered.map((tx) => (
                  <div
                    key={tx.orderId}
                    className="p-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800/80 shadow-sm space-y-4"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className={`w-2.5 h-2.5 rounded-full ${
                          tx.status === 'SUCCESS' ? 'bg-emerald-500' : tx.status === 'PENDING' ? 'bg-amber-500 animate-pulse' : 'bg-rose-500'
                        }`}></span>
                        <span className="text-xs font-mono font-bold text-slate-900 dark:text-white">
                          {tx.orderId}
                        </span>
                      </div>
                      <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                        tx.status === 'SUCCESS'
                          ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60'
                          : tx.status === 'PENDING'
                          ? 'text-amber-800 dark:text-amber-300 bg-amber-100 dark:bg-amber-950/80 font-mono'
                          : 'text-rose-700 bg-rose-50'
                      }`}>
                        {tx.status === 'SUCCESS' ? `PAID · ₹${tx.amount.toLocaleString('en-IN')}` : tx.status === 'PENDING' ? 'PENDING ADMIN APPROVAL' : 'REJECTED'}
                      </span>
                    </div>

                    <div className="text-xs space-y-1 text-slate-600 dark:text-slate-300">
                      <div><strong className="text-slate-900 dark:text-white">Purpose:</strong> {tx.purpose}</div>
                      <div><strong className="text-slate-900 dark:text-white">Customer:</strong> {tx.customerName} ({tx.customerPhone})</div>
                      <div><strong className="text-slate-900 dark:text-white">Date:</strong> <span className="font-mono">{tx.createdAt}</span></div>
                      <div><strong className="text-slate-900 dark:text-white">Submitted UTR:</strong> <span className="font-mono">{tx.utrNumber || tx.cfPaymentId}</span></div>
                    </div>

                    {tx.status === 'PENDING' && (
                      <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 text-xs text-amber-800 dark:text-amber-300 flex items-center justify-between">
                        <span>⏳ Waiting for Admin (raunakgaya99@gmail.com) to verify & input gift card code.</span>
                      </div>
                    )}

                    {tx.status === 'SUCCESS' && tx.redeemCode && (
                      <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900 flex items-center justify-between">
                        <div>
                          <span className="text-[10px] font-bold text-indigo-700 dark:text-indigo-300 block uppercase">
                            Play Store Code
                          </span>
                          <span className="font-mono text-sm font-black text-slate-900 dark:text-white select-all">
                            {tx.redeemCode}
                          </span>
                        </div>
                        <button
                          onClick={() => handleCopy(tx.redeemCode!)}
                          className="p-2 text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 rounded-lg hover:bg-white dark:hover:bg-slate-800 transition-colors"
                          title="Copy Code"
                        >
                          {copiedCode === tx.redeemCode ? (
                            <Check className="w-4 h-4 text-emerald-500" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    )}

                    <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                      <button
                        onClick={() => onSelectTransaction(tx)}
                        className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
                      >
                        View Full Receipt
                      </button>
                      {tx.redeemCode && (
                        <a
                          href={`https://play.google.com/redeem?code=${tx.redeemCode}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                        >
                          <span>Redeem on Google Play</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

      </div>
    </section>
  );
};
