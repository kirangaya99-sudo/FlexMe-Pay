import React, { useState } from 'react';
import { POPULAR_GAMES } from '../data/mockData';
import { GameProduct } from '../types/payment';
import { Sparkles, ArrowRight, ShieldCheck, Gamepad2, Check } from 'lucide-react';

interface GameTopUpProps {
  onInitiatePayment: (orderData: {
    amount: number;
    customerName: string;
    customerPhone: string;
    customerEmail: string;
    purpose: string;
    isPlayStoreOrder: boolean;
  }) => void;
}

export const GameTopUp: React.FC<GameTopUpProps> = ({ onInitiatePayment }) => {
  const [selectedGame, setSelectedGame] = useState<GameProduct>(POPULAR_GAMES[0]);
  const [playerId, setPlayerId] = useState<string>('');
  const [selectedTier, setSelectedTier] = useState<number>(POPULAR_GAMES[0].minAmount);
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [customerEmail, setCustomerEmail] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const tiers = [
    selectedGame.minAmount,
    Math.round(selectedGame.minAmount * 2.5),
    Math.round(selectedGame.minAmount * 5),
    Math.round(selectedGame.minAmount * 10),
  ];

  const handleSelectGame = (game: GameProduct) => {
    setSelectedGame(game);
    setSelectedTier(game.minAmount);
  };

  const validate = (): boolean => {
    const errs: { [key: string]: string } = {};
    if (!playerId.trim()) {
      errs.playerId = `Please enter your ${selectedGame.name} Player ID / UID`;
    }
    if (!customerName.trim()) {
      errs.customerName = 'Please enter your name';
    }
    if (!customerPhone.trim() || customerPhone.replace(/\D/g, '').length < 10) {
      errs.phone = 'Valid 10-digit mobile number required for SMS receipt';
    }
    if (!customerEmail.trim() || !customerEmail.includes('@')) {
      errs.email = 'Valid email required for confirmation';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onInitiatePayment({
      amount: selectedTier,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail.trim(),
      purpose: `${selectedGame.name} (${selectedGame.denomination}) - Player UID: ${playerId.trim()}`,
      isPlayStoreOrder: true,
    });
  };

  return (
    <section id="game-topup-section" className="py-12 bg-white dark:bg-slate-900 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="max-w-3xl mb-10">
          <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2">
            Game & PW Subscriptions
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white">
            Direct In-Game Top-Up & Course Pass
          </h2>
          <p className="mt-2 text-sm sm:text-base text-slate-600 dark:text-slate-400">
            Recharge Free Fire Diamonds, BGMI UC, Roblox Robux, or Physics Wallah digital batches with zero fee using Cashfree fast checkout.
          </p>
        </div>

        {/* Game Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5 mb-10">
          {POPULAR_GAMES.map((game) => {
            const isSelected = selectedGame.id === game.id;
            return (
              <button
                key={game.id}
                type="button"
                onClick={() => handleSelectGame(game)}
                className={`p-4 rounded-xl border text-left transition-all relative ${
                  isSelected
                    ? 'border-indigo-600 dark:border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/40 ring-2 ring-indigo-500/20'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50/40 dark:bg-slate-800/40 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="text-2xl mb-2">{game.icon}</div>
                <div className="text-sm font-bold text-slate-900 dark:text-white truncate">
                  {game.name}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                  {game.denomination}
                </div>
                <div className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 mt-2 tabular-nums">
                  From ₹{game.minAmount}
                </div>
              </button>
            );
          })}
        </div>

        {/* Top-Up Form */}
        <div className="bg-slate-50/60 dark:bg-slate-800/30 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            
            <div className="flex items-center gap-3 pb-4 border-b border-slate-200 dark:border-slate-700/60">
              <span className="text-3xl">{selectedGame.icon}</span>
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  Recharge {selectedGame.name}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Instant credit delivery to your registered game ID via Cashfree
                </p>
              </div>
            </div>

            {/* Select Denomination Tier */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                Select {selectedGame.denomination} Pack
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {tiers.map((tierAmt) => (
                  <button
                    key={tierAmt}
                    type="button"
                    onClick={() => setSelectedTier(tierAmt)}
                    className={`py-3 px-4 rounded-xl border text-center transition-all ${
                      selectedTier === tierAmt
                        ? 'border-indigo-600 dark:border-indigo-500 bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 font-bold shadow-sm'
                        : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="text-base font-black tabular-nums">₹{tierAmt}</div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      Instant Credit
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Player ID & Details */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {selectedGame.name} Player ID / UID *
                </label>
                <input
                  type="text"
                  value={playerId}
                  onChange={(e) => setPlayerId(e.target.value)}
                  placeholder="e.g. 5184910284"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                {errors.playerId && (
                  <p className="text-xs text-rose-500 mt-1 font-medium">{errors.playerId}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Your Full Name *
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Raunak Kumar"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                {errors.customerName && (
                  <p className="text-xs text-rose-500 mt-1 font-medium">{errors.customerName}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Mobile Number (For SMS Confirmation) *
                </label>
                <input
                  type="tel"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                {errors.phone && (
                  <p className="text-xs text-rose-500 mt-1 font-medium">{errors.phone}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="e.g. raunak@example.com"
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                {errors.email && (
                  <p className="text-xs text-rose-500 mt-1 font-medium">{errors.email}</p>
                )}
              </div>
            </div>

            {/* Checkout Button */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full sm:w-auto py-3.5 px-8 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-99"
              >
                <span>Pay via Cashfree (₹{selectedTier.toLocaleString('en-IN')})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </form>
        </div>

      </div>
    </section>
  );
};
