import React from 'react';

interface FooterProps {
  onNavClick: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavClick }) => {
  return (
    <footer className="border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 py-10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-8 border-b border-slate-200 dark:border-slate-800">
          <div>
            <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white">
              PlayStore Payment <span className="text-emerald-600 dark:text-emerald-400">by PW</span>
            </span>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm">
              Instant Google Play redeem codes and secure digital payment collection powered by Cashfree Payments.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-slate-600 dark:text-slate-400">
            <button onClick={() => onNavClick('recharge')} className="hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer">
              Play Store Cards
            </button>
            <button onClick={() => onNavClick('games')} className="hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer">
              Game Top-Up
            </button>
            <button onClick={() => onNavClick('collect')} className="hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer">
              Collect Payment
            </button>
            <button onClick={() => onNavClick('track')} className="hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer">
              Track Order
            </button>
            <button onClick={() => onNavClick('merchant')} className="hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer">
              Merchant Desk
            </button>
            <button onClick={() => onNavClick('support')} className="hover:text-slate-950 dark:hover:text-white transition-colors cursor-pointer text-indigo-600 dark:text-indigo-400 font-semibold">
              Helpline Support Bot
            </button>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-[11px] text-slate-500 dark:text-slate-400">
          <p>
            © {new Date().getFullYear()} PlayStore Payment by PW · All rights reserved. Powered by Cashfree Payments India Pvt. Ltd.
          </p>
          <p>
            Google Play is a registered trademark of Google LLC. RBI Authorized Payment Aggregator ecosystem.
          </p>
        </div>

      </div>
    </footer>
  );
};
